#!/bin/bash

m_user="$1"
m_pwd="$2"
m_db="$3"
m_host="$4"
m_port="$5"
m_socket="mysql-socket"
mysql_bin="mysql"

time_1day_ago_18="$(date +"%Y-%m-%d" --date='1 day ago') 18:00:00"
time_current="$(date +"%Y-%m-%d %H:%M:%S")"
time_today_8="$(date +"%Y-%m-%d") 08:00:00"
time_today_18="$(date +"%Y-%m-%d") 18:00:00"
time_tomorrow_8="$(date +"%Y-%m-%d" --date='1 day') 08:00:00"
time_1year_ago="$(date +"%Y-%m-%d" --date='365 day ago') 00:00:00"

sql_run_complete=$(echo "select count(id) from tb_backup_recover_log where userid = 'container' and begintime > '${time_1day_ago_18}';")
sql_run_fail=$(echo "select count(id) from tb_backup_recover_log where userid = 'container' and iresult <> 0 and begintime > '${time_1day_ago_18}';")
sql_run_success=$(echo "select count(id) from tb_backup_recover_log where userid = 'container' and iresult = 0 and begintime > '${time_1day_ago_18}';")
sql_not_update_task_yesterday=$(echo "select count(id) from tb_backup_backup_task where user_id = 'container' and status = 1 and next_execute_time > '${time_1day_ago_18}' and next_execute_time < '${time_today_8}';")
sql_not_update_task_1year_ago=$(echo "select count(id) from tb_backup_backup_task where user_id = 'container' and status = 1 and next_execute_time > '${time_1year_ago}' and next_execute_time < '${time_today_8}';")
sql_next_task=$(echo "select count(id) from tb_backup_backup_task where user_id = 'container' and status = 1 and next_execute_time > '${time_today_18}' and next_execute_time < '${time_tomorrow_8}';")

MYSQL_CMD=$(echo ${mysql_bin} -u${m_user} -p${m_pwd} -P${m_port} -h${m_host} ${m_db})

DoSelectData(){
    local SQL1="$1"
    local value_tmp="$(${MYSQL_CMD} -e "${SQL1}" 2>/dev/null |egrep "[[:digit:]]+")"
    if [ x"${value_tmp}" != x"" ]; then
        echo "${value_tmp}"
    else
        echo "FAIL"
    fi
    sleep 0
}

main(){
    local d1_sum="$(DoSelectData "${sql_run_complete}")"
    local d1_success="$(DoSelectData "${sql_run_success}")"
    local d1_fail="$(DoSelectData "${sql_run_fail}")"
    local d1_update_fail="$(DoSelectData "${sql_not_update_task_yesterday}")"
    local y1_update_fail="$(DoSelectData "${sql_not_update_task_1year_ago}")"
    local d2_next_sum="$(DoSelectData "${sql_next_task}")"
    echo "    ###### Swift Backup Task Check Tool ######"
    echo "$(date +"%Y-%m-%d %H:%M:%S"), 备份任务执行情况检查:"
    echo "$(date +"%Y-%m-%d %H:%M:%S"), 检查时间段: ${time_1day_ago_18} 至 ${time_current}, 备份任务已执行: ${d1_sum} 个, 成功: ${d1_success} 个, 失败: ${d1_fail} 个, 运行中: $(( ${d1_sum} - ${d1_success} - ${d1_fail} )) 个; 度量标准: 已执行 = 成功 + 失败 + 运行中, 重点检查运行中的任务."
    echo "$(date +"%Y-%m-%d %H:%M:%S"), 检查时间段: ${time_1day_ago_18} 至 ${time_today_8}, 昨日备份任务下次执行时间更新失败: ${d1_update_fail} 个; 度量标准: 等于0."
    echo "$(date +"%Y-%m-%d %H:%M:%S"), 检查时间段: ${time_1year_ago} 至 ${time_today_8}, 最近 1 年备份任务下次执行时间更新失败: ${d1_update_fail} 个; 度量标准: 等于0."
    echo "$(date +"%Y-%m-%d %H:%M:%S"), 检查时间段: ${time_today_18} 至 ${time_tomorrow_8}, 今日备份任务计划执行: ${d2_next_sum} 个; 度量标准: 对比相邻两天巡检数值是否相等."
}

main 
