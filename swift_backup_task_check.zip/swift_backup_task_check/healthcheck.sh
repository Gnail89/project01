#!/bin/bash

cd ./ansible-project/playbooks/playbook_swift_C1_check/
ansi_cmd="./ansible-project/apps/python-2.7.13/bin/ansible-playbook"
ansi_hosts="./ansible-project/playbooks/playbook_swift_C1_check/hosts"

result_file3="./swift_c1-BackupTaskCheck-$(date "+%Y").txt"

#backup task check
msg="$("${ansi_cmd}" -f 10 -i "${ansi_hosts}" "main_C1_backup_task.yml")"
msg_cache="$(echo "${msg}" |grep "str_out.stdout" |sed -e 's/^.*\"str_out.stdout\": \"//g' -e 's/\\n/\\\n/g' -e 's/\\//g' -e 's/\"$//g')"
echo "${msg_cache}" >> "${result_file3}"
